# mod4-practice

## Codespace module 4 - Examples, exercises and practice repository

### How to **serve** the web project. In the terminal:

npm run serve

### How to **build** the web project. In the terminal:

npm run build

### How to **run tests** with Jest. In the terminal:

npm run test

### Including your files in the project:

- any Javascript file import it in 'src/js/main.js' like _import 'myFile.js'_.

- any CSS or SCSS file import it in 'src/scss/style.js' like _@import 'myFile.css'_.
