// STYLES
import "../scss/style.scss";
// JAVASCRIPT
import "./exercises/e1-movie";

// La practica 2, en practice/practice2.js y utils/filterFilms.js

// La practica 3 la encontramos en movie-api.js, 
// tiene en consola, al realizar npm run serve, el objeto de peliculas generado con la practica 3.
