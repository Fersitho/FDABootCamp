export const movieApiDefaults: any = {
    baseUrl: 'https://api.themoviedb.org/3/',
    apiKey: 'c22fb38c26ba2c2d1c63e9fb3f150618',
    lang: 'en-EN'
}