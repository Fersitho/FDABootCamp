export enum typeLoadMovie {
    nowPlaying = 'now_playing',
    popular = 'popular',
    topRated = 'top_rated',
    upcoming = 'upcoming'
}